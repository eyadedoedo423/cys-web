# Inside the CPU: ALU, Registers, Control Unit

In this lesson, we unpack the foundations and see how the part works with the whole.

- Objectives
- Key terms & mental models
- Hands-on mini-task
- Common pitfalls & checks

:::quiz NVMe primarily connects over? || SATA || PCIe* || I2C :::
