# Memory Hierarchy: Registers → Cache → RAM → Disk

In this lesson, we unpack the foundations and see how the part works with the whole.

- Objectives
- Key terms & mental models
- Hands-on mini-task
- Common pitfalls & checks

:::quiz Which level of memory is fastest? || Disk || L1 cache* || DRAM :::
