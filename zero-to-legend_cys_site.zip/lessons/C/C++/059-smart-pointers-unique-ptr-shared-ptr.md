# Smart Pointers: unique_ptr, shared_ptr

Systems programming rewards precision; we’ll build safe, fast code step by step.

- Objectives
- Key terms & mental models
- Hands-on mini-task
- Common pitfalls & checks

```cpp
#include <bits/stdc++.h>
using namespace std;
int main(){
    vector<int> v={1,2,3,4,5};
    cout << accumulate(v.begin(), v.end(), 0) << "\n";
}
```

:::quiz Which C++ feature manages lifetime automatically? || RAII* || GOTO || Macros :::
