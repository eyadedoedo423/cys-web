# Pointers, Arrays, and Strings

Systems programming rewards precision; we’ll build safe, fast code step by step.

- Objectives
- Key terms & mental models
- Hands-on mini-task
- Common pitfalls & checks

```c
#include <stdio.h>
int main(void){
    int a=5, b=7;
    printf("%d + %d = %d
", a, b, a+b);
    return 0;
}
```

:::quiz Which C++ feature manages lifetime automatically? || RAII* || GOTO || Macros :::
