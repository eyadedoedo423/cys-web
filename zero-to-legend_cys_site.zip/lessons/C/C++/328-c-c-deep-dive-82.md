# C/C++ Deep Dive 82

This is a structured deep-dive slot.

- Objectives
- Reading links (add your own)
- Exercise: summarize what you learned

:::quiz Mark as complete? || No || Yes* :::
