# Debugging C with gdb

Systems programming rewards precision; we’ll build safe, fast code step by step.

- Objectives
- Key terms & mental models
- Hands-on mini-task
- Common pitfalls & checks

```c
#include <stdio.h>
int main(void){
    int a=5, b=7;
    printf("%d + %d = %d
", a, b, a+b);
    return 0;
}
```

:::quiz What frees heap memory in C? || delete || free()* || dispose :::
