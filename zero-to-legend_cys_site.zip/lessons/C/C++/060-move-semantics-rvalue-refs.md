# Move Semantics & Rvalue Refs

Systems programming rewards precision; we’ll build safe, fast code step by step.

- Objectives
- Key terms & mental models
- Hands-on mini-task
- Common pitfalls & checks

```cpp
#include <bits/stdc++.h>
using namespace std;
int main(){
    vector<int> v={1,2,3,4,5};
    cout << accumulate(v.begin(), v.end(), 0) << "\n";
}
```

:::quiz What frees heap memory in C? || delete || free()* || dispose :::
