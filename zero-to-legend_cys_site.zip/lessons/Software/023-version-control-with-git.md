# Version Control with Git

We’ll connect core OS and engineering concepts to practical day-to-day tasks.

- Objectives
- Key terms & mental models
- Hands-on mini-task
- Common pitfalls & checks

```bash
# create and activate virtual env
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
```

:::quiz What command initializes a new Git repo? || git start || git init* || git new :::
