# Control Flow & Functions

Let’s build a mental model of Python and write code you can trust.

- Objectives
- Key terms & mental models
- Hands-on mini-task
- Common pitfalls & checks

```python
# Fibonacci with memoization
from functools import lru_cache

@lru_cache(None)
def fib(n):
    return n if n < 2 else fib(n-1)+fib(n-2)

print([fib(i) for i in range(10)])
```

:::quiz Which is non-blocking concurrency? || threading || asyncio* || multiprocessing :::
